<?php
// Se include fișierul de configurare. 
require_once 'config.php'; 
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Acasă - FC Argeș Basketball</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
   <header>
    <div class="brand" style="display: flex; align-items: center; gap: 15px;">
        <img src="fc_arges.png" alt="FC Argeș Logo" style="width: 60px; height: auto; border-radius: 5px; margin-bottom: 5px;">
        
        <div>
            <div style="font-weight: 900; font-size: 1.5rem; line-height: 1.2;">FC Argeș Basketball</div>
            <div class="muted" style="font-size: 13px;">Echipa oficială</div>
        </div>
    </div>
  <nav style="display: flex; gap: 20px;">
    <a href="index.php" style="color: #ffffff; font-weight: 700; font-size: 16px; text-decoration: none;">Acasă</a>
    <a href="pagina_jucatori.php" style="color: #ffffff; font-weight: 700; font-size: 16px; text-decoration: none;">Jucători</a>
    <a href="pagina_staff.php" style="color: #ffffff; font-weight: 700; font-size: 16px; text-decoration: none;">Staff</a> 
    <a href="pagina_calendar.php" style="color: #ffffff; font-weight: 700; font-size: 16px; text-decoration: none;">Calendar</a>
    <a href="pagina_contact.php" style="color: #ffffff; font-weight: 700; font-size: 16px; text-decoration: none;">Contact</a>
</nav>
</header>
   
    <section class="hero">
        <h1>Bine ați venit la FC Argeș Basketball</h1>
        <p>Echipa oficială — rezultate, meciuri și noutăți. Susține-ne la următorul meci!</p>
        <a class="cta" href="pagina_calendar.php">Următorul meci: Sâmbătă • 19:00</a>

        <div class="stats">
            <div class="stat"><small>Sezon</small><b>2025/26</b></div>
            <div class="stat"><small>Loc</small><b>3</b></div>
            <div class="stat"><small>Ultimul meci</small><b>V</b></div>
        </div>
    </section>
    <style>
    /* Forțăm culoarea portocalie direct din pagină */
    .standings-table td {
        color: #ff6b35 !important; 
        font-weight: 700 !important;
        border: 1px solid #dddddd !important;
    }

    /* Păstrăm rândul FC Argeș cu Mov pentru contrast */
    .standings-table .highlight-team td {
        color: #5e2b97 !important;
        background-color: #f3e5f5 !important;
    }

    /* Capul de tabel rămâne mov cu scris alb */
    .standings-table th {
        background-color: #5e2b97 !important;
        color: #ffffff !important;
    }
</style>
    <section class="standings-section">
    <h2>Clasament LNBM - Sezon 2025/26</h2>
    <div class="table-container">
        <table class="standings-table">
            <thead>
                <tr>
                    <th>Loc</th>
                    <th>Echipă</th>
                    <th>Meciuri</th>
                    <th>Victorii</th>
                    <th>Înfrangeri</th>
                    <th>Puncte</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>U-BT Cluj-Napoca</td>
                    <td>12</td>
                    <td>11</td>
                    <td>1</td>
                    <td>23</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>CSM Oradea</td>
                    <td>12</td>
                    <td>10</td>
                    <td>2</td>
                    <td>22</td>
                </tr>
                <tr class="highlight-team">
                    <td>3</td>
                    <td><strong>FC Argeș Pitești</strong></td>
                    <td>12</td>
                    <td>9</td>
                    <td>3</td>
                    <td>21</td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>CSO Voluntari</td>
                    <td>12</td>
                    <td>8</td>
                    <td>4</td>
                    <td>20</td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>Rapid București</td>
                    <td>12</td>
                    <td>7</td>
                    <td>5</td>
                    <td>19</td>
                </tr>
            </tbody>
        </table>
    </div>
    <p class="muted small-text">* Clasament actualizat la data de 12 Ianuarie 2026</p>
</section>
    <section class="sponsors">
        <h3>Sponsorii noștri</h3>
        <div class="sponsors-grid">
            <img src="sponsor1.jpeg" alt="Sponsor 1" class="sponsor-img">
            <img src="sponsor2.jpeg" alt="Sponsor 2" class="sponsor-img">
            <img src="sponsor3.jpeg" alt="Sponsor 3" class="sponsor-img">
            <img src="sponsor4.jpeg" alt="Sponsor 4" class="sponsor-img">
        </div>
    </section>
    <footer>© 2025 FC Argeș Basketball — Toate drepturile rezervate.</footer>
</div>
</body>
</html>

<?php
// 4. Închide conexiunea la sfârșitul paginii
if (isset($conn) && $conn) {
    mysqli_close($conn);
}
?>